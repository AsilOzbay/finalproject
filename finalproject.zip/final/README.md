# IMBD_clone0
complete front end website using JS,CSS and HTML. used TMBD Api to access movie from thier database
